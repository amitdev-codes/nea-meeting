<?php

return [
    'name' => 'Landingpage',
];
