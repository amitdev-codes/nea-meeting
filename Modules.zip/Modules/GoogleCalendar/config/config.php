<?php

return [
    'name' => 'GoogleCalendar',
];
