<?php

return [
    'name' => 'NeaMeeting',
];
