<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Pagination Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the paginator library to build
    | the simple pagination links. You are free to change them to anything
    | you want to customize your views to better match your application.
    |
    */

    'previous' => '&laquo; पहिले',
    'next' => 'अर्को &raquo;',
    'showing' => 'देखाउँदै',
    'to' => 'सम्म',
    'of' => 'को',
    'results' => 'परिणाम',

];
